#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass CS_WeapGun_SMG_Vector_Ironsight.CS_WeapGun_SMG_Vector_Ironsight_C
// Size: 0x160 // Inherited bytes: 0x160
struct UCS_WeapGun_SMG_Vector_Ironsight_C : UCameraShake {
};

