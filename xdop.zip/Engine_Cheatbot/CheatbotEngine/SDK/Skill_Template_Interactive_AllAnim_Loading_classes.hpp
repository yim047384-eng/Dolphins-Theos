#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass Skill_Template_Interactive_AllAnim_Loading.Skill_Template_Interactive_AllAnim_Loading_C
// Size: 0x8a0 // Inherited bytes: 0x898
struct ASkill_Template_Interactive_AllAnim_Loading_C : AUAESkill {
	// Fields
	struct USceneComponent* DefaultSceneRoot; // Offset: 0x898 // Size: 0x08

	// Functions

	// Object Name: Function Skill_Template_Interactive_AllAnim_Loading.Skill_Template_Interactive_AllAnim_Loading_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1048d7660 // Return & Params: Num(0) Size(0x0)
};

