#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass PickUp_BP_Pants_06_B.PickUp_BP_Pants_06_B_C
// Size: 0x978 // Inherited bytes: 0x970
struct APickUp_BP_Pants_06_B_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* Bag_03_icon; // Offset: 0x970 // Size: 0x08

	// Functions

	// Object Name: Function PickUp_BP_Pants_06_B.PickUp_BP_Pants_06_B_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1048d7660 // Return & Params: Num(0) Size(0x0)
};

