// SDK GENERATE BY TELEGRAM ;- (@Manish8x) (4.7.0 -- 64Bit) DM TO BUY TOOL AVLABLE FOR SELL
// Telegram:- @Manish8x
// GEN ONWed Nov 18 07:25:37 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By Tg @Manish8x---------------------------
//Functions
//---------------------By Tg @Manish8x---------------------------

// Function EZUMG.EnhancedButton.GetCurrentHeldDuration
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float UEnhancedButton::GetCurrentHeldDuration()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedButton.GetCurrentHeldDuration");

	UEnhancedButton_GetCurrentHeldDuration_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EnhancedButton.ForceCancel
// (Final, Native, Public, BlueprintCallable)

void UEnhancedButton::ForceCancel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedButton.ForceCancel");

	UEnhancedButton_ForceCancel_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EnhancedButton.ApplyConfig
// (Final, Native, Public, BlueprintCallable)

void UEnhancedButton::ApplyConfig()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedButton.ApplyConfig");

	UEnhancedButton_ApplyConfig_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EnhancedSlider.SetUnfilledBarColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue                        (Parm, IsPlainOldData)

void UEnhancedSlider::SetUnfilledBarColor(const struct FLinearColor& InValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.SetUnfilledBarColor");

	UEnhancedSlider_SetUnfilledBarColor_Params params;
	params.InValue = InValue;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EnhancedSlider.SetOnlyRespondToThumb
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InValue                        (Parm, ZeroConstructor, IsPlainOldData)

void UEnhancedSlider::SetOnlyRespondToThumb(bool InValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.SetOnlyRespondToThumb");

	UEnhancedSlider_SetOnlyRespondToThumb_Params params;
	params.InValue = InValue;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EnhancedSlider.SetFilledBarColor
// (Final, Native, Public, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InValue                        (Parm, IsPlainOldData)

void UEnhancedSlider::SetFilledBarColor(const struct FLinearColor& InValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.SetFilledBarColor");

	UEnhancedSlider_SetFilledBarColor_Params params;
	params.InValue = InValue;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EnhancedSlider.SetEnableSteppedSliding
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           InValue                        (Parm, ZeroConstructor, IsPlainOldData)

void UEnhancedSlider::SetEnableSteppedSliding(bool InValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.SetEnableSteppedSliding");

	UEnhancedSlider_SetEnableSteppedSliding_Params params;
	params.InValue = InValue;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EnhancedSlider.GetUnfilledBarColor
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FLinearColor            ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FLinearColor UEnhancedSlider::GetUnfilledBarColor()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.GetUnfilledBarColor");

	UEnhancedSlider_GetUnfilledBarColor_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EnhancedSlider.GetOnlyRespondToThumb
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UEnhancedSlider::GetOnlyRespondToThumb()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.GetOnlyRespondToThumb");

	UEnhancedSlider_GetOnlyRespondToThumb_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EnhancedSlider.GetFilledBarColor
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FLinearColor            ReturnValue                    (Parm, OutParm, ReturnParm, IsPlainOldData)

struct FLinearColor UEnhancedSlider::GetFilledBarColor()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.GetFilledBarColor");

	UEnhancedSlider_GetFilledBarColor_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EnhancedSlider.GetEnableSteppedSliding
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UEnhancedSlider::GetEnableSteppedSliding()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EnhancedSlider.GetEnableSteppedSliding");

	UEnhancedSlider_GetEnableSteppedSliding_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzAnimationLibrary.DuplicateAnimWithRemap
// (Final, Native, Static, Public, HasOutParms, BlueprintCallable)
// Parameters:
// class UUserWidget*             OwningWidget                   (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidgetAnimation*        Template                       (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// TMap<class UWidget*, class UWidget*> RemapTable                     (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
// class UWidgetAnimation*        ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidgetAnimation* UEzAnimationLibrary::DuplicateAnimWithRemap(class UUserWidget* OwningWidget, class UWidgetAnimation* Template, TMap<class UWidget*, class UWidget*> RemapTable)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzAnimationLibrary.DuplicateAnimWithRemap");

	UEzAnimationLibrary_DuplicateAnimWithRemap_Params params;
	params.OwningWidget = OwningWidget;
	params.Template = Template;
	params.RemapTable = RemapTable;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzAnimationLibrary.DuplicateAnimRebindTrack
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UUserWidget*             OwningWidget                   (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidgetAnimation*        Template                       (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidget*                 SourceWidget                   (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidget*                 TargetWidget                   (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidgetAnimation*        ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidgetAnimation* UEzAnimationLibrary::DuplicateAnimRebindTrack(class UUserWidget* OwningWidget, class UWidgetAnimation* Template, class UWidget* SourceWidget, class UWidget* TargetWidget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzAnimationLibrary.DuplicateAnimRebindTrack");

	UEzAnimationLibrary_DuplicateAnimRebindTrack_Params params;
	params.OwningWidget = OwningWidget;
	params.Template = Template;
	params.SourceWidget = SourceWidget;
	params.TargetWidget = TargetWidget;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzAnimationLibrary.DuplicateAnimForWidget
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UUserWidget*             OwningWidget                   (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidgetAnimation*        Template                       (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidget*                 TargetWidget                   (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class UWidgetAnimation*        ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidgetAnimation* UEzAnimationLibrary::DuplicateAnimForWidget(class UUserWidget* OwningWidget, class UWidgetAnimation* Template, class UWidget* TargetWidget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzAnimationLibrary.DuplicateAnimForWidget");

	UEzAnimationLibrary_DuplicateAnimForWidget_Params params;
	params.OwningWidget = OwningWidget;
	params.Template = Template;
	params.TargetWidget = TargetWidget;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzFactory.SetNum
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            NumItems                       (Parm, ZeroConstructor, IsPlainOldData)

void UEzFactory::SetNum(int NumItems)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzFactory.SetNum");

	UEzFactory_SetNum_Params params;
	params.NumItems = NumItems;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EzFactory.RemoveLastItem
// (Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UEzFactory::RemoveLastItem()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzFactory.RemoveLastItem");

	UEzFactory_RemoveLastItem_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzFactory.GetFactoryItemCount
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UEzFactory::GetFactoryItemCount()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzFactory.GetFactoryItemCount");

	UEzFactory_GetFactoryItemCount_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzFactory.AddItem
// (Native, Public, BlueprintCallable)
// Parameters:
// class UWidget*                 ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class UWidget* UEzFactory::AddItem()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzFactory.AddItem");

	UEzFactory_AddItem_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelectable.OnStateRefresh
// (Event, Public, BlueprintEvent)
// Parameters:
// EEzItemState                   NewState                       (Parm, ZeroConstructor, IsPlainOldData)

void UEzSelectable::OnStateRefresh(EEzItemState NewState)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelectable.OnStateRefresh");

	UEzSelectable_OnStateRefresh_Params params;
	params.NewState = NewState;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EzSelector.SetSelection
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)

void UEzSelector::SetSelection(int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.SetSelection");

	UEzSelector_SetSelection_Params params;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EzSelector.SetSelectedIndex
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)

void UEzSelector::SetSelectedIndex(int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.SetSelectedIndex");

	UEzSelector_SetSelectedIndex_Params params;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EzSelector.SetItemEnabled
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            ItemIndex                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnabled                       (Parm, ZeroConstructor, IsPlainOldData)

void UEzSelector::SetItemEnabled(int ItemIndex, bool bEnabled)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.SetItemEnabled");

	UEzSelector_SetItemEnabled_Params params;
	params.ItemIndex = ItemIndex;
	params.bEnabled = bEnabled;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EzSelector.IsItemSelected
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ItemIndex                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UEzSelector::IsItemSelected(int ItemIndex)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.IsItemSelected");

	UEzSelector_IsItemSelected_Params params;
	params.ItemIndex = ItemIndex;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelector.IsItemEnabled
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ItemIndex                      (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UEzSelector::IsItemEnabled(int ItemIndex)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.IsItemEnabled");

	UEzSelector_IsItemEnabled_Params params;
	params.ItemIndex = ItemIndex;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelector.GetSelectedIndices
// (Native, Public, HasOutParms, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// TArray<int>                    OutIndices                     (Parm, OutParm, ZeroConstructor)

void UEzSelector::GetSelectedIndices(TArray<int>* OutIndices)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.GetSelectedIndices");

	UEzSelector_GetSelectedIndices_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (OutIndices != nullptr)
		*OutIndices = params.OutIndices;
}


// Function EZUMG.EzSelector.GetSelectedIndex
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UEzSelector::GetSelectedIndex()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.GetSelectedIndex");

	UEzSelector_GetSelectedIndex_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelector.GetNumSelectedItems
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UEzSelector::GetNumSelectedItems()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.GetNumSelectedItems");

	UEzSelector_GetNumSelectedItems_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelector.GetItemState
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ItemIndex                      (Parm, ZeroConstructor, IsPlainOldData)
// EEzItemState                   ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

EEzItemState UEzSelector::GetItemState(int ItemIndex)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.GetItemState");

	UEzSelector_GetItemState_Params params;
	params.ItemIndex = ItemIndex;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelector.GetHoveredIndex
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UEzSelector::GetHoveredIndex()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.GetHoveredIndex");

	UEzSelector_GetHoveredIndex_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelector.GetFocusedIndex
// (Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UEzSelector::GetFocusedIndex()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.GetFocusedIndex");

	UEzSelector_GetFocusedIndex_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.EzSelector.ForceSelection
// (Native, Public, BlueprintCallable)
// Parameters:
// int                            Index                          (Parm, ZeroConstructor, IsPlainOldData)

void UEzSelector::ForceSelection(int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.ForceSelection");

	UEzSelector_ForceSelection_Params params;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.EzSelector.ClearSelection
// (Native, Public, BlueprintCallable)

void UEzSelector::ClearSelection()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.EzSelector.ClearSelection");

	UEzSelector_ClearSelection_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialPanel.SetStartAngleOffset
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InStartAngleOffset             (Parm, ZeroConstructor, IsPlainOldData)

void URadialPanel::SetStartAngleOffset(float InStartAngleOffset)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialPanel.SetStartAngleOffset");

	URadialPanel_SetStartAngleOffset_Params params;
	params.InStartAngleOffset = InStartAngleOffset;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialPanel.SetSectorPadding
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InSectorPadding                (Parm, ZeroConstructor, IsPlainOldData)

void URadialPanel::SetSectorPadding(float InSectorPadding)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialPanel.SetSectorPadding");

	URadialPanel_SetSectorPadding_Params params;
	params.InSectorPadding = InSectorPadding;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialPanel.SetArrangement
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// ERadialArrangement             InArrangement                  (Parm, ZeroConstructor, IsPlainOldData)

void URadialPanel::SetArrangement(ERadialArrangement InArrangement)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialPanel.SetArrangement");

	URadialPanel_SetArrangement_Params params;
	params.InArrangement = InArrangement;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialPanel.GetAngleAtPosition
// (Final, Native, Public, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector2D               LocalPosition                  (Parm, IsPlainOldData)
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float URadialPanel::GetAngleAtPosition(const struct FVector2D& LocalPosition)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialPanel.GetAngleAtPosition");

	URadialPanel_GetAngleAtPosition_Params params;
	params.LocalPosition = LocalPosition;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.RadialSlot.SlotAsRadialSlot
// (Final, Native, Static, Public, BlueprintCallable, BlueprintPure)
// Parameters:
// class UWidget*                 Widget                         (Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
// class URadialSlot*             ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class URadialSlot* URadialSlot::SlotAsRadialSlot(class UWidget* Widget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SlotAsRadialSlot");

	URadialSlot_SlotAsRadialSlot_Params params;
	params.Widget = Widget;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.RadialSlot.SetSectorSizeValue
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          Value                          (Parm, ZeroConstructor, IsPlainOldData)

void URadialSlot::SetSectorSizeValue(float Value)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SetSectorSizeValue");

	URadialSlot_SetSectorSizeValue_Params params;
	params.Value = Value;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialSlot.SetSectorSizeRule
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// TEnumAsByte<enum ESectorSizeRule> InRule                         (Parm, ZeroConstructor, IsPlainOldData)

void URadialSlot::SetSectorSizeRule(TEnumAsByte<enum ESectorSizeRule> InRule)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SetSectorSizeRule");

	URadialSlot_SetSectorSizeRule_Params params;
	params.InRule = InRule;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialSlot.SetSectorColorAndOpacity
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable)
// Parameters:
// struct FLinearColor            InTint                         (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)

void URadialSlot::SetSectorColorAndOpacity(const struct FLinearColor& InTint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SetSectorColorAndOpacity");

	URadialSlot_SetSectorColorAndOpacity_Params params;
	params.InTint = InTint;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialSlot.SetSectorBrush
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FSlateBrush             InBrush                        (ConstParm, Parm, OutParm, ReferenceParm)

void URadialSlot::SetSectorBrush(const struct FSlateBrush& InBrush)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SetSectorBrush");

	URadialSlot_SetSectorBrush_Params params;
	params.InBrush = InBrush;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialSlot.SetOuterRadiusRatio
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InOuterRadiusRatio             (Parm, ZeroConstructor, IsPlainOldData)

void URadialSlot::SetOuterRadiusRatio(float InOuterRadiusRatio)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SetOuterRadiusRatio");

	URadialSlot_SetOuterRadiusRatio_Params params;
	params.InOuterRadiusRatio = InOuterRadiusRatio;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialSlot.SetInnerRadiusRatio
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// float                          InInnerRadiusRatio             (Parm, ZeroConstructor, IsPlainOldData)

void URadialSlot::SetInnerRadiusRatio(float InInnerRadiusRatio)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SetInnerRadiusRatio");

	URadialSlot_SetInnerRadiusRatio_Params params;
	params.InInnerRadiusRatio = InInnerRadiusRatio;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialSlot.SetAutoSize
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bInAutoSize                    (Parm, ZeroConstructor, IsPlainOldData)

void URadialSlot::SetAutoSize(bool bInAutoSize)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.SetAutoSize");

	URadialSlot_SetAutoSize_Params params;
	params.bInAutoSize = bInAutoSize;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function EZUMG.RadialSlot.GetCenterRadiusRatio
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float URadialSlot::GetCenterRadiusRatio()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.GetCenterRadiusRatio");

	URadialSlot_GetCenterRadiusRatio_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.RadialSlot.GetCenterAngle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float URadialSlot::GetCenterAngle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.GetCenterAngle");

	URadialSlot_GetCenterAngle_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.RadialSlot.GetArcSize
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

float URadialSlot::GetArcSize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSlot.GetArcSize");

	URadialSlot_GetArcSize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.RadialSelector.GetChildIndexByVector
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector2D               CenterOffset                   (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// float                          DeadzoneLength                 (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int URadialSelector::GetChildIndexByVector(const struct FVector2D& CenterOffset, float DeadzoneLength)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSelector.GetChildIndexByVector");

	URadialSelector_GetChildIndexByVector_Params params;
	params.CenterOffset = CenterOffset;
	params.DeadzoneLength = DeadzoneLength;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.RadialSelector.GetChildIndexByAngle
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// float                          Angle                          (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int URadialSelector::GetChildIndexByAngle(float Angle)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSelector.GetChildIndexByAngle");

	URadialSelector_GetChildIndexByAngle_Params params;
	params.Angle = Angle;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.RadialSelector.GetChildIndexAtPosition
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector2D               LocalPosition                  (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int URadialSelector::GetChildIndexAtPosition(const struct FVector2D& LocalPosition)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.RadialSelector.GetChildIndexAtPosition");

	URadialSelector_GetChildIndexAtPosition_Params params;
	params.LocalPosition = LocalPosition;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function EZUMG.VerticalSelector.GetChildIndexAtPosition
// (Final, Native, Public, HasOutParms, HasDefaults, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// struct FVector2D               LocalPosition                  (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UVerticalSelector::GetChildIndexAtPosition(const struct FVector2D& LocalPosition)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function EZUMG.VerticalSelector.GetChildIndexAtPosition");

	UVerticalSelector_GetChildIndexAtPosition_Params params;
	params.LocalPosition = LocalPosition;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

