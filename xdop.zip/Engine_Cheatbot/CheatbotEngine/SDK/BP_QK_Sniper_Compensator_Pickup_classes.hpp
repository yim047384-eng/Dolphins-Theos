#pragma once

#include <cstdio>
#include <string>
#include <cstdint>

// Object Name: BlueprintGeneratedClass BP_QK_Sniper_Compensator_Pickup.BP_QK_Sniper_Compensator_Pickup_C
// Size: 0x978 // Inherited bytes: 0x970
struct ABP_QK_Sniper_Compensator_Pickup_C : APickUpWrapperActor {
	// Fields
	struct UStaticMeshComponent* SM_QK_Sniper_Compensator; // Offset: 0x970 // Size: 0x08

	// Functions

	// Object Name: Function BP_QK_Sniper_Compensator_Pickup.BP_QK_Sniper_Compensator_Pickup_C.UserConstructionScript
	// Flags: [Event|Public|BlueprintCallable|BlueprintEvent]
	void UserConstructionScript(); // Offset: 0x1048d7660 // Return & Params: Num(0) Size(0x0)
};

